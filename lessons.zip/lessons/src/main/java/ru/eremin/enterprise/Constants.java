package ru.eremin.enterprise;

public class Constants {
    public static final String CATALOG = "catalog";
    public static final String PRODUCT = "product";
    public static final String ART = "art";
    public static final String CART = "cart";
    public static final String AMOUNT = "amount";
}
